# Next steps to the deadline

**Deadline:** Mon 2026-10-06 23:59 CEST = **17:59 EDT**. Aim to submit by Mon 12:00 EDT, which leaves a buffer.

Submission requirements:
- A public **Apache-2.0** repo with runnable code and data (or public data URLs).
- A video (optional, but it matters for the 50% "convincing showcase" score).
- A description of at most 5,000 characters. The draft in `docs/SUBMISSION.md` is 4,505.

## Must do (blocking submission)
| # | Task | Owner | Notes |
|---|---|---|---|
| 1 | Rehearse the notebook shot in a live **JupyterLab** | you (or me, if you share a browser session) | `uv sync --extra notebook && uv run --with jupyterlab jupyter lab examples/video_demo.ipynb`. Confirm the widget renders, clicks accept, and `w.cleaned` updates. Report anything broken. |
| 2 | Install the VS Code extension and try it on `demo/video/auto_mpg_dirty.csv` | you | `cd vscode-proofread && npm install && npx @vscode/vsce package && code --install-extension proofread-tables-0.1.0.vsix` |
| 3 | Record the video (about 2.5 minutes) | you | Shot list, narration and verified numbers: `docs/DEMO_SCRIPT.md`. Terminal about 180×40, large font. |
| 4 | Final review of the README and `docs/SUBMISSION.md` | you + me | Check every claim against `handoff/data/*` (already cross-checked once) |
| 5 | Create the public GitHub repo and push | **you** | I must not push. Before pushing: `git init`, check `.gitignore` (venv, logs, `node_modules`, `.vscode-test`, `data_cache`, `*.vsix`), and run the leak scan in RUNBOOK §8. Replace the placeholder `repository.url` in `vscode-proofread/package.json`. |
| 6 | Submit the form | **you** | Title, description, repo link, video link |

## Should do (raises the score; about half a day each, or less)
| # | Task | Why | Effort |
|---|---|---|---|
| 7 | Record a 30-second agent clip: an LLM uses the MCP tools to review `auto_mpg_dirty` and write a cleaning memo | Judges like agents; the hackathon brief mentions agents | 1 h |
| 8 | Add a GIF of the terminal viewer (accept → green) at the top of the README | First impression on GitHub | 30 min |
| 9 | Decide whether to file the upstream issues (`docs/UPSTREAM_ISSUES.md`) before submitting | Credibility with Prior Labs. It's public, so it's your call. | 15 min |
| 10 | Draft final release notes and tag text (no push from me) | Polish | 15 min |

## Could do (only if there's time; keep claims modest)
- **Categorical-cell checks** with the TabPFN classifier on each categorical column. It would need its own small
  pre-registered test before any claims.
- **Larger tables:** sampling or Fast mode for more than 5k rows, with measured runtimes.
- **A real-error benchmark:** a public dataset with known, documented errors (beyond the anecdotal Pima and Buick).
- **Merge the `tabpfn-extensions` comparison** into the app's Benchmark tab.

## Risks and mitigations
| Risk | Mitigation |
|---|---|
| A live notebook demo fails in JupyterLab | Fall back to the terminal viewer and VS Code shots, which are verified. The static HTML report still renders. |
| A judge can't download the weights (gated license) | All demos replay saved reports with no model. The README explains the one-time license acceptance. |
| GPU host shared with another workload | Always check `nvidia-smi` first and only use GPUs 0–3 (RUNBOOK §2). Everything for the demo is precomputed. |
| An over-claim slips into the video | Use the "Claims to avoid" list in `docs/DEMO_SCRIPT.md`, and read every number from `data/demo_answer_key.json`. |
| Last-minute code edits break things | Re-run the clean-copy check (RUNBOOK §7) after any change, and freeze code by Sun evening. |

## Suggested timeline
- **Sat 10-04:** items 1–2 (rehearse), 7–8 (agent clip, GIF), fix anything found. Freeze code Sat night if possible.
- **Sun 10-05:** item 3 (record), item 4 (review), re-run the clean-copy check.
- **Mon 10-06 morning:** items 5–6 (push, submit) before 12:00 EDT. The buffer runs to 17:59 EDT.
