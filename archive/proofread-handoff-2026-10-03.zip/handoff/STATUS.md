# Status (2026-10-03 21:58 EDT)

## The product in one line
**Proofread is a spellcheck for tables.** TabPFN-3.5 predicts every cell from the rest of its row, with a full
predictive distribution and no training, then flags values that are implausible *for that row*. It suggests the likely
value, names the probable slip (×10 / ÷10 / ×1000, swapped digits, sign flip, 0 for missing) and checks labels too.

## What's built (all working and tested)
| Surface | Entry point | Notes |
|---|---|---|
| Python library | `from proofread import Proofreader, Report` · `Proofreader().check(df, label=...)` | `device="auto"`, `fast=True` uses TabPFN-3.5-Fast (not benchmarked) |
| CLI | `uv run proofread check data.csv --label y --out reports/x` | writes `.md`, `.issues.csv`, `.html`, `.json`; `--report PATH` for an exact JSON path |
| Terminal viewer | `uv run proofread view data.csv` or `… view report.json` | highlighted grid, side panel, keys `n p a d u f s q`; saves `*.cleaned.csv` + `*.decisions.json` |
| Notebook | `import proofread` → `df.proofread.view(label=...)` · `report.widget()` · `%proofread df` | anywidget; `w.cleaned`, `w.decisions`; a report renders as static HTML |
| VS Code extension | `vscode-proofread/` → `.vsix` | squiggles on CSV cells, hover details, quick fix "Replace with …", Problems panel |
| Browser app | `uv run proofread app` | Streamlit; examples replay without a GPU; CSV upload runs live |
| Agent (MCP) | `uv run proofread mcp` | `list_reports, get_issues, get_row, report_markdown, benchmark_summary, proofread_csv` (live tool gated by `PROOFREAD_ALLOW_INFERENCE=1`) |
| Research module | `chainofcustody/`, `auditkit/` | stress-testing via gradients through TabPFN's in-context learning (secondary) |

Packaging: distribution `tabpfn-proofread` 0.3.0 (Python 3.12), command `proofread`, license Apache-2.0.

## Headline results (pre-registered; all datasets reported)
Source: `data/proofread_confirmation_summary.json`, `data/proofread_addendum_summary.json`.

| Test | Result |
|---|---|
| **H6, cell errors.** Precision@k vs the best of 7 baselines per dataset (chosen after the fact) | **13/14 datasets**, mean +0.190 [+0.132, +0.240], one-sided Wilcoxon p = 0.00018 |
| **H7, label errors.** AUROC vs the best of 4 baselines | **13/14**, mean +0.022 [+0.008, +0.041], p = 0.00085 |
| **A1, vs Prior Labs' TabPFN outlier detector** (`tabpfn-extensions`), row AUROC | **14/14**, mean +0.264, p = 0.00006; cell precision@k also 14/14 |
| **A2, default threshold** (surprise ≥ 2) | precision **87.9%**, recall 53.3% (threshold 3: 94.8% / 19.0%) |
| Error types | TabPFN has the best AUROC on all 5 types; swapped values 0.852 vs 0.785 for the best baseline (z-score 0.562) |
| Ablation | Predictive-distribution score beats TabPFN's point-residual score on 14/14 (precision@k 0.72 vs 0.54) |
| Determinism | Addendum reproduced the confirmation precision@k exactly (max diff 0.0) |
| Known loss | climate-crashes (independent simulation parameters: no structure between columns); z-score wins 0.42 vs 0.34 |

**Real-data examples:**
- **Pima diabetes:** impossible zeros flagged (BMI, glucose, blood pressure); insulin and skin-fold zeros reported as a
  placeholder code.
- **Auto MPG (untouched):** the #1 flag is the 1970 Buick Estate Wagon at 3,086 lb. TabPFN expects 4,471, and the
  published curb weight is about 4,770 lb. The same row is in seaborn's `mpg` dataset.

**Demo set** (Auto MPG + 8 planted typos, `data/demo_answer_key.json`):
- 7 of 8 caught. Six are ranked in the top 7; the 7th-ranked flag is the real Buick. The planted label error is the top
  label flag, at rank 18.
- **3 of the planted errors are invisible to a z-score:** Civic 4,354 lb (z = 0.71; TabPFN expects 1,877, truth 1,795),
  Mustang 5.0 L (expects 302.03, truth 302) and VW Rabbit 0 hp (expects 70, truth 70).
- **Missed:** the Corolla's 32 → 23 mpg (surprise 1.95, just under 2).

## Upstream bugs found (not yet filed)
Three GPU-only crashes in `tabpfn-extensions` 0.6.3 with `tabpfn` 9.1.0:
- `outliers` and `pval_crt`: float32 vs float64 dtype mismatch.
- `generate_synthetic_data`: CPU vs GPU device mismatch.

They aren't CUDA-version specific (same behaviour with torch 2.4.1/CUDA 12.1), and no existing GitHub issues mention
them. Ready-to-file text is in `docs/UPSTREAM_ISSUES.md`; the survey and workaround are in `docs/KNOWN_ISSUES.md`.

## Test status (clean copy installed from the lockfile, 2026-10-03)
- **Python:** 45 tests pass, including an end-to-end CPU test with real TabPFN-3.5 and headless tests of the terminal
  viewer and notebook widget.
- **Notebooks:** both example notebooks execute in a real Jupyter kernel.
- **Apps:** the Streamlit app check (6 passes) and the MCP stdio check (5 passes) both pass.
- **JavaScript:** widget tests pass in jsdom (3/3), and the VS Code extension's unit tests pass (3/3).
- **VS Code integration:** passes in a real VS Code 1.140 (80 squiggles; the quick fix edits the cell).
- **Reproducibility:** results documents regenerate byte-for-byte from stored JSON.
- **Leak scan:** clean (no internal hostnames, paths or registry URLs).

## Known gaps
- The notebook widget hasn't been run inside a live **JupyterLab** browser session. It's verified piecewise: jsdom,
  kernel output, and Chrome rendering with a stand-in model.
- Only numeric columns get cell checks; categorical cells don't. Benchmarked tables were 400 rows.
- The evidence is mostly injected errors; the real-data cases are anecdotal (Pima, the Auto MPG Buick).
- No video yet. The GitHub repository isn't created or pushed.
