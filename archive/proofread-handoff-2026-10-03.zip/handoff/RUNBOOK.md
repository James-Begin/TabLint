# Runbook

All commands run from the project root unless noted otherwise. The local Mac has no GNU `timeout` and its Python lacks
the project dependencies. Run Python and tests on the GPU host, or wherever `uv sync` has been done.

## 1. Install
```bash
uv sync --extra demo --extra agent --extra notebook      # Python 3.12; add --extra baselines for tabpfn-extensions
```
On first use, TabPFN-3.5 weights download after a one-time browser license acceptance. They're cached in
`~/.cache/tabpfn`.

## 2. GPU host rules (shared machine)
- Host: `ssh -n -o BatchMode=yes -o ConnectTimeout=30 main.Credit-Modeling.jamesbegin.coder '<cmd>'`.
  Filter the noise with `| grep -v -iE 'version mismatch|download v2'`. The project mirror is at `~/forensics`.
- **Use GPUs 0–3 only**, and only if they're empty. Another workload sometimes uses the others. Check first:
  `nvidia-smi --query-gpu=index,memory.used --format=csv,noheader`
  Guard: `sh scripts/free_gpu.sh` prints a free GPU (under 500 MiB used) or exits 1. Never launch onto a busy GPU.
- Always set `CUDA_VISIBLE_DEVICES` explicitly. Wrap long jobs in `timeout` and run them detached
  (`setsid nohup … < /dev/null &`). Keep thread counts small (`OMP_NUM_THREADS=1–8`).
- Never `pkill -f` a pattern that also matches your own shell command; use `pgrep -f "[p]attern"`.
- Don't touch other directories on the host (`~/coder`, `~/scoremender` and `~/arcpfn`, except their own results).
- To sync code to the host: `COPYFILE_DISABLE=1 tar czf /tmp/x.tgz <paths> && scp -q /tmp/x.tgz <host>:forensics/ && ssh <host> 'cd ~/forensics && tar xzf x.tgz && rm x.tgz'`

## 3. Use the product
```bash
uv run proofread check data.csv --label outcome --out reports/data         # GPU if available, else CPU
uv run proofread view data.csv                                             # terminal viewer (runs check, then opens)
uv run proofread view demo/video/auto_mpg_dirty.proofread.json             # saved report, opens instantly
uv run proofread app                                                       # browser (Streamlit)
uv run proofread mcp                                                       # agent tools (stdio)
uv run --with jupyterlab jupyter lab examples/video_demo.ipynb             # notebook demo
```
Python: `import proofread; df.proofread.view(label="y")`, `Report.load(p).widget()`, or `%load_ext proofread` then
`%proofread df --label y`.

## 4. Tests
```bash
CUDA_VISIBLE_DEVICES="" uv run pytest -q tests                                        # 45 tests
CUDA_VISIBLE_DEVICES="" uv run --with nbclient --with nbformat python experiments/check_notebook.py proofread_notebook.ipynb
CUDA_VISIBLE_DEVICES="" uv run --with nbclient --with nbformat python experiments/check_notebook.py video_demo.ipynb
uv run --extra demo python experiments/check_proofread_app.py                         # Streamlit runtime check
uv run --extra agent python experiments/check_proofread_mcp.py                        # MCP stdio check
cd tests/js && npm install && npm test                                                 # notebook widget JS (jsdom)
cd vscode-proofread && npm install && npm test && npm run test:integration             # VS Code unit + real-VS-Code test
```
`npm install` on the work laptop resolves through the corporate mirror. **Don't commit the lockfiles it writes**
(`tests/js/package-lock.json` is gitignored). For `vscode-proofread/package-lock.json`, the URLs were rewritten to
`registry.npmjs.org`, and all 42 resolve. Redo the rewrite if it's regenerated.

## 5. Demo assets (video)
```bash
CUDA_VISIBLE_DEVICES=0 PYTHONPATH=. uv run python benchmarks/make_video_demos.py      # demo/video/* + answer_key.json
uv run python benchmarks/make_video_shots.py                                          # terminal SVG screenshots
python3 scripts/render_widget_preview.py                                              # widget preview HTML (for a screenshot)
CUDA_VISIBLE_DEVICES=0 PYTHONPATH=. uv run python benchmarks/make_demos.py            # app demos (Pima, Magic, breast)
```

## 6. Reproduce the benchmarks
```bash
CUDA_VISIBLE_DEVICES=0 PYTHONPATH=. uv run python benchmarks/proofread_confirm.py     # H6/H7 (shard with --datasets)
uv run python benchmarks/summarize_proofread.py results/proofread
CUDA_VISIBLE_DEVICES=0 PYTHONPATH=. uv run --extra baselines python benchmarks/proofread_addendum.py   # A1/A2
uv run python benchmarks/summarize_addendum.py results/proofread_addendum
uv run python benchmarks/make_proofread_results.py && uv run python benchmarks/make_figures.py
CUDA_VISIBLE_DEVICES=0 uv run --extra baselines --with scikit-survival python scripts/check_tabpfn_extensions_gpu.py   # upstream bug survey
```
Pre-registrations and their SHA-256 hashes are in `docs/PREREGISTRATIONS.md`. **Don't edit those files.** Put errata in
`docs/KNOWN_ISSUES.md`.

## 7. Clean-copy check (run after any change)
Copy the tree (excluding `.venv`, logs, `node_modules`, `.vscode-test`, `vscode-proofread/out`, `*.vsix`,
`data_cache`, `results/stale`) into a fresh directory on the host. Then run `uv sync --frozen --extra demo --extra agent
--extra notebook`, everything in §4, and confirm that `benchmarks/make_proofread_results.py` and
`experiments/make_results.py` regenerate `docs/PROOFREAD_RESULTS.md` and `docs/RESULTS.md` identically (`cmp`).

## 8. Leak scan before any push
```bash
grep -rIl --exclude-dir=.venv --exclude-dir=__pycache__ --exclude-dir=logs --exclude-dir=node_modules \
  --exclude-dir=.vscode-test --exclude-dir=out --exclude-dir=data_cache \
  -iE "reposerver|w10e|wealthsimple|jamesbegin|Credit-Modeling|/home/coder|/Users/james" . | grep -v redact_paths.py
python3 experiments/redact_paths.py results        # redacts machine paths in stored artifacts (values unchanged)
```
The expected scan output is empty.
