# Artifact index

## Product code
- `proofread/`: `core.py` (detection, `Report`, `set_cell`), `cli.py`, `tui.py` (terminal viewer), `notebook.py`
  (widget, accessor, magic), `static/widget.{js,css}`, `mcp_server.py`
- `demo/proofread_app.py`: Streamlit app
- `vscode-proofread/`: VS Code extension (`src/mapping.ts`, `src/extension.ts`, tests, fixtures)
- `examples/`: `proofread_notebook.ipynb`, `video_demo.ipynb`, `widget_preview.html`
- Research module: `chainofcustody/`, `auditkit/`, `fz/`, `experiments/`; early pilots in `research/pilots/`

## Proofread evidence
| What | Where |
|---|---|
| Pre-registration (H6, H7) | `docs/PROOFREAD_PREREG.md` (hash in `docs/PREREGISTRATIONS.md`) |
| Confirmation runs (70) | `results/proofread/*.json`, summary `results/proofread/summary.json`, `analysis.txt` |
| Addendum pre-registration (A1, A2) | `docs/PROOFREAD_ADDENDUM_PREREG.md` |
| Addendum runs (70) | `results/proofread_addendum/*.json`, `summary.json`, `analysis.txt` |
| Generated results document | `docs/PROOFREAD_RESULTS.md` (from `benchmarks/make_proofread_results.py`) |
| Figures | `docs/figures/proofread_hero.png`, `proofread_error_types.png`, `proofread_product.png`, `proofread_tui.svg`, `proofread_notebook_widget.png`, `video_tui_real_buick.svg`, `video_tui_civic.svg` |
| Pilots (exploratory) | `results/pilots/` (cells, label_pilot, conformal, al, pima_real.json) |
| App demo reports | `results/proofread_demos/` (Pima real; Magic, breast-cancer injected; Auto MPG real and dirty) |
| Comparison with tabpfn-extensions | `docs/COMPARISON_TABPFN_EXTENSIONS.md` |

## Demo video
- `docs/DEMO_SCRIPT.md`: shot list, narration, verified numbers, claims to avoid
- `demo/video/`: `auto_mpg.csv`, `auto_mpg_dirty.csv`, `*.proofread.json`, `answer_key.json`, `README.md`
  (CC BY 4.0 attribution)
- Generators: `benchmarks/video_data.py`, `make_video_demos.py`, `make_video_shots.py`

## Upstream bugs
- `docs/UPSTREAM_ISSUES.md`: ready-to-file issue text
- `docs/KNOWN_ISSUES.md`: survey, root causes, workaround, errata
- `scripts/repro_tabpfn_extensions_cuda_dtype.py`, `scripts/check_tabpfn_extensions_gpu.py`

## Stress-test research module (secondary)
- `docs/CHAIN_OF_CUSTODY.md`, `docs/RESULTS.md` (generated), pre-registrations `docs/CONFIRMATION*_PREREG.md`,
  `docs/REGIME_*_PREREG.md`, `docs/COMPARISONS_PREREG.md`
- `results/confirmation/`, `confirmation2/`, `regimes/`, `regime_screen/`, `development*/`, `exploratory_steps40/`,
  `stability_check.json`, `numerical_recovery/`

## Submission
- `docs/SUBMISSION.md`: form description (4,505 characters) and a pointer to the demo script
- `README.md`, `LICENSE` (Apache-2.0), `NOTICE` (data attributions), `pyproject.toml`, `uv.lock`

## Copies of key summaries
`handoff/data/` holds the Proofread confirmation and addendum summaries plus their analysis text, the demo answer key,
the regime-screen table, and the stress-test summaries.
