# Handoff: Proofread (TabPFN-3.5 hackathon)

> **Private working notes.** This folder contains internal host names and local paths, and is **gitignored**. Do not
> publish it. Everything public-facing is in `README.md` and `docs/`.

Snapshot written 2026-10-03 21:58 EDT. Hackathon deadline: **Mon 2026-10-06, 23:59 CEST (17:59 EDT)**.

| File | What it's for |
|---|---|
| [STATUS.md](STATUS.md) | What the product is, what's built, headline results, test status |
| [NEXT_STEPS.md](NEXT_STEPS.md) | Plan and checklist to the deadline, with risks and stretch goals |
| [RUNBOOK.md](RUNBOOK.md) | Every command: tests, viewers, demos, benchmarks, GPU and remote rules |
| [DECISIONS_LOG.md](DECISIONS_LOG.md) | How we got here: pivots, null results, lessons, incidents |
| [ARTIFACTS.md](ARTIFACTS.md) | Where every result, figure, pre-registration and demo file lives |
| `data/` | Copies of the key result summaries (small JSON/text), so the numbers survive even if `results/` is moved |

Project root: `/Users/james.begin/dev/forensics`, mirrored to `~/forensics` on the GPU host.
**Nothing has been committed or pushed to Git.**
