# Decisions log

## Directions tried and dropped (NO-GO)
| Direction | Result | Why dropped |
|---|---|---|
| ScoreMender (piano score repair; `~/scoremender`) | Pitch repair: TabPFN 43.9% vs copy baseline 42.3% vs HGB 43.7%; fine-tuning 44.3% | Tied with trees |
| ARC per-cell (`~/arcpfn`) | TabPFN 16/277 vs `hgb_small` 18; episodic fine-tuning 15/277 | Tied or lost |
| Chain of Custody: gradient stress tests through in-context learning | Pre-registered: supported on 3 of 7 datasets (breast cancer 60% vs 13%; eeg-eye-state 93% vs 43%; MagicTelescope 67% vs 27%); not on credit-g, taiwan (12 or 40 steps), phoneme or mozilla4 | Mixed results, and the pitch was hard to land. Kept as a secondary research module (`docs/CHAIN_OF_CUSTODY.md`, `docs/RESULTS.md`). |
| Leave-one-out poisoning detection | TabPFN LOO AUROC 0.99/0.90/0.94, but logistic-regression LOO matched it (H5 not supported in any regime) | Not uniquely better than a cheap detector |
| Gradient label-error score (soft-label gradients) | AUROC 0.34–0.69 over 22 pilot runs | Weak |
| Removing detected label errors to improve accuracy | Barely changes TabPFN accuracy; TabPFN-3.5 is robust to 10% uniform noise | No practical gain |
| Full conformal prediction with TabPFN | Set sizes similar to split conformal in a pilot | No efficiency win |
| Look-ahead (expected-error-reduction) active learning | Not better than random or margin sampling in a pilot; about 50× slower | Failed |

## The pivot that worked: Proofread
- Out-of-fold TabPFN label-error detection was best or tied-best on 8/8 pilot datasets. That pointed to the idea of
  using TabPFN's **conditional distribution of every cell**.
- The cell-error pilot had TabPFN best in 23/24 runs. A pre-registered confirmation on 14 datasets × 5 seeds then
  supported both H6 and H7.
- Product framing: "spellcheck for tables". Viewers were built for the terminal, the notebook, VS Code, the browser
  and an agent (MCP).

## Key methodological decisions
- **Pre-register before each confirmatory run.** Freeze the files and record their hashes in
  `docs/PREREGISTRATIONS.md`. Put errata in `docs/KNOWN_ISSUES.md`; never edit the frozen files.
- **Compare against the best baseline per dataset, chosen after the fact.** It's conservative on purpose.
- **Report every dataset and every null**, including the climate-crashes loss and the missed Corolla.
- **The default threshold changed from 3 to 2** *after* the A2 analysis. That's a disclosed product setting, not a
  tested hypothesis.
- **The label classifier uses 4 estimators** to match the benchmarked configuration.
- **Integer columns get whole-number suggestions.** This fixed a crash on accept found while building the demo.
- **The `tabpfn-extensions` baseline needed a float64 shim on GPU.** It's documented as an upstream bug, and the same
  thing happens implicitly on CPU.

## Incidents and lessons
- An earlier session crashed the workspace with an unbounded `Pool.imap`. Since then: bounded producers only, `timeout`
  on every job, small thread counts.
- Twice I launched onto GPUs that another workload was using. I killed the jobs within about a minute; one small job
  ran out of memory. Since then: check GPUs before launching (`scripts/free_gpu.sh`) and use only 0–3.
- `pkill -f` once matched its own SSH shell. Use `pgrep -f "[p]attern"`.
- npm lockfiles picked up internal registry URLs. Rewrite them to `registry.npmjs.org` and verify they resolve, or
  gitignore them.
- Over-claims were caught and fixed before shipping: the "barely heavier than a Pinto" wording, a z-score computed on
  a different basis, an illustrative README label example that wasn't real output, and the "no values changed"
  wording for the shim.
