import json, glob, collections, numpy as np
from scipy.stats import wilcoxon
R = [json.load(open(f)) for f in sorted(glob.glob("results/*.json"))]
print(f"{len(R)} tables")
def get(r, k, m="precision_at_k"): return r["runs"][k][m]
for m in ("precision_at_k", "auroc"):
    print(f"\n== {m}: per-dataset mean over seeds")
    print(f"{'dataset':18} {'v3 num':>8} {'3.5 num':>8} {'v3 hc':>8} {'3.5 hc':>8}  3.5>v3(hc) seeds")
    by = collections.defaultdict(list)
    for r in R: by[r["dataset"]].append(r)
    for ds, rs in by.items():
        v = {k: np.mean([get(r, k, m) for r in rs]) for k in ("v3|num", "v3.5|num", "v3|hc", "v3.5|hc")}
        w = sum(get(r, "v3.5|hc", m) > get(r, "v3|hc", m) for r in rs)
        print(f"{ds:18} {v['v3|num']:8.3f} {v['v3.5|num']:8.3f} {v['v3|hc']:8.3f} {v['v3.5|hc']:8.3f}  {w}/{len(rs)}")
    a = np.array([get(r, "v3.5|hc", m) - get(r, "v3|hc", m) for r in R])
    b = np.array([(get(r, "v3.5|hc", m) - get(r, "v3.5|num", m)) - (get(r, "v3|hc", m) - get(r, "v3|num", m)) for r in R])
    c = np.array([get(r, "v3.5|num", m) - get(r, "v3|num", m) for r in R])
    for name, x in (("H1 3.5-v3 on hc", a), ("H2 interaction", b), ("3.5-v3 on num", c)):
        nz = x[x != 0]
        p = wilcoxon(nz, alternative="greater").pvalue if len(nz) else float("nan")
        print(f"  {name:18} mean {x.mean():+.4f}  wins {int((x>0).sum())} losses {int((x<0).sum())} ties {int((x==0).sum())}  one-sided Wilcoxon p={p:.4f}")
sec = collections.defaultdict(list)
for r in R:
    for k, v in r["runs"].items(): sec[k].append(v["seconds"])
print("\nmean seconds/table:", {k: round(np.mean(v)) for k, v in sec.items()})
