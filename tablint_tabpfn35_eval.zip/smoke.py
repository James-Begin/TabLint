import time, numpy as np
from tabpfn import TabPFNRegressor
from tabpfn.constants import ModelVersion
rng=np.random.default_rng(0); X=rng.normal(size=(300,5)); y=X[:,0]*2+np.sin(X[:,1])+rng.normal(scale=.1,size=300)
for v in [ModelVersion.V3, ModelVersion.V3_5]:
  for dev in ["mps","cpu"]:
    t=time.time()
    try:
        m=TabPFNRegressor.create_default_for_version(v, device=dev, random_state=0).fit(X[:240],y[:240])
        o=m.predict(X[240:],output_type="full"); print(v.value, dev, "ok", round(time.time()-t,1), np.mean((o['median']-y[240:])**2))
    except Exception as e: print(v.value, dev, "ERR", repr(e)[:300])
