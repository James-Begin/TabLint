# TabLint: judging notes, "does 3.5 matter?" experiment, and improvement handoff

Repo reviewed: https://github.com/James-Begin/TabLint @ `d0abdfc` (2026-10-05).
Hackathon: Prior Labs TabPFN-3.5 Hackathon. Judging, as found via search: creativity and innovation; performance (what
TabPFN-3.5 unlocks on hard tabular problems); completeness (a public repo is required and a video is strongly recommended).

---

## 1. Verdict (short)

TabLint is a **strong finalist but not the winner as submitted**. Its strengths are a real, technically sound idea
(scoring each cell against TabPFN's out-of-fold predictive distribution), unusual rigor (pre-registered
benchmarks), and a polished multi-surface product (Jupyter, VS Code, browser, terminal UI, CLI, MCP).

Main blockers:
1. **It does not show what 3.5 specifically unlocks.** The repo's own pre-registered comparison has 3.5 ≈ v3
   (6 wins, 8 losses, mean −0.010; `docs/VERSION_COMPARISON.md`), and 3.5 is slower.
2. **The headline is cherry-picked.** "12/12, +22.2 pts" is a subset chosen after analysis, dropping climate-crashes (a
   loss) and eeg-eye-state (a win). The honest pre-registered result, 13/14 with +19.0 pts and p=0.00018, is nearly as strong.
3. **The demo video is a stylized animation**, and one suggestion in it (USA → Japan) is illustrative, not a model output.
4. **The README CI badge shows failure.** The latest 5 runs on GitHub concluded "failure"; on the latest commit all
   three jobs were cancelled after about 15 minutes, which looks like runner trouble rather than failing tests.

---

## 2. Where TabPFN underperforms, or the repo hurts it (from the repo's own results)

Numbers were recomputed from `results/*.json`. The per-seed comparisons are against the per-seed best of 7 baselines,
which is a harsh, noisy bar; the seed-averaged comparisons are the more reliable signal.

**Numerical cells (`results/proofread/`)**
- climate-crashes: an outright loss. Precision@k 0.34 vs 0.42 for z-score, losing on all 5 seeds. Cell AUROC 0.757 vs 0.817.
  Suggested fixes are worse than the column median (1.05 vs 0.87 SD). It loses on every error type, worst on offset
  (0.826 vs 0.974).
- eeg-eye-state loses to z-score on 2 of 5 seeds.
- Seed-averaged error types where a baseline wins: banknote decimal/offset/transposition, phoneme swap/zero,
  spambase transposition, wilt transposition.
- TabPFN's point-prediction residual gets 54.1% precision@k, about the same as the best baselines. The gain comes from
  distribution scoring, not better point predictions.

**Labels:** diabetes is a loss (0.843 vs 0.848 logistic, all 5 seeds). Wins are ≤ +0.004 AUROC on 5 of 14 datasets;
the mean gain is only +0.022.

**Categorical:** tips loses on seed-averaged AUROC (0.828 vs 0.829). There are per-seed ties or losses on cmc, credit-g,
penguins and tips. Absolute precision is low: credit-g 0.16, nursery 0.20, car/cmc 0.24.

**Versions:** 3.5 < v3 on 8 of 14 datasets (ilpd on all 5 seeds). climate-crashes collapses on 3.5 (0.35 vs 0.50 on v2/v3).
3.5 uses 3045 GPU-seconds vs 1876 for v3.

**Product threshold (2):** recall is 53% (climate-crashes 17%, diabetes 39%). At threshold 3, recall is 19%.

**Real data (`docs/FAMOUS_DATASETS.md`):** 8 of 71 top-10 flags are verified errors (7 of them in diamonds). The documented
UCI Iris errors were all missed. The diamonds sample was enriched with every impossible-zero row, which inflates the
verified-error count.

**tabpfn-extensions:** the outlier detector scores row AUROC < 0.5 on 3 tables, and 3 extension features crash on CUDA.
The bugs are documented in the repo but not filed upstream.

**Code that handicaps TabPFN (`proofread/core.py`)**
- Text columns with more than 30 levels are excluded from context entirely (`categorical_columns`, `text_cats`). This is
  the main issue; see section 3.
- The label is appended to the regression context *after* `reg_cat` is computed, so a multiclass label is treated as
  an ordinal number. The categorical path, by contrast, declares it categorical.
- The PIT score is clipped at 1e-12, so extreme cells tie at a surprise of about 11.7 and cannot be ranked.
- A new estimator is built for every fold (5 per column). Timings include model loading on every fit.
- `_patterns` labels ordinary low-cardinality columns (Titanic pclass/sibsp/parch, planets `number`) as placeholder
  codes. Its message says those cells "are not flagged individually", but the code only changes the `cause` text.
- The classifier uses `n_estimators=4`. Whether this is below the 3.5 default is [UNVERIFIED].

---

## 3. Experiment: does 3.5 matter when the context has high cardinality?

**Rationale.** The TabPFN 9.0.0 3.5 architecture (`architectures/tabpfn_v3_5.py`) adds Fourier value embeddings plus an
ECDF-rank metadata path, documented as needed to "keep high-cardinality ordinal categorical values distinct". v3 has
none of this. By contrast, the library's text handling (`TRANSFORM_TEXT`, tf-idf + SVD) is version-agnostic preprocessing,
so it cannot show a 3.5 advantage.

**Protocol.** See `PROTOCOL.md`, hashed in `PROTOCOL.sha256` before the real runs. One pilot run on seed 999
(`pilot/`) only checked that the script ran and how long it took.
- Injection and scoring are TabLint's own: `inject()` is executed from `benchmarks/proofread_confirm.py`, the score is
  PIT surprise, and predictions are 5-fold out-of-fold.
- Datasets: employee_salaries (OpenML 42125, n=1000), medical_charges (OpenML 42720, n=1000), and auto_mpg (TabLint's
  demo file, 398 rows).
- Arms: `num` gives TabPFN what TabLint gives it today; `hc` adds the high-cardinality columns as declared categoricals
  (ordinal codes from sorted unique values).
- Models: v3 and v3.5. Seeds 1001–1005, giving 15 tables. Device: CPU on an Apple M4 Pro.

**Results** (`analysis.txt`). Precision@k means over seeds:

| Dataset | v3 num | 3.5 num | v3 hc | 3.5 hc | 3.5 > v3 (hc) |
|---|---:|---:|---:|---:|---:|
| auto_mpg | 0.841 | 0.831 | 0.841 | 0.846 | 2/5 |
| employee_salaries | 0.723 | 0.759 | 0.750 | **0.789** | 4/5 |
| medical_charges | 0.752 | 0.743 | 0.781 | **0.804** | 3/5 |

| Test (15 paired tables) | Mean | W / L / T | One-sided Wilcoxon p |
|---|---:|---:|---:|
| H1: 3.5 − v3 on `hc` | +2.2 pts | 9 / 2 / 4 | **0.012** |
| H2: (3.5 hc−num) − (v3 hc−num) | +1.7 pts | 10 / 3 / 2 | **0.029** |
| 3.5 − v3 on `num` (descriptive) | +0.5 pts | 7 / 6 / 2 | 0.32 |

On AUROC with `hc`, 3.5 > v3 on 13 of 15 tables (p=0.0008), including all 5 seeds on both employee_salaries and medical_charges.
Mean seconds per table: v3 ≈ 75, 3.5 ≈ 160 (CPU).

**Interpretation.** With TabLint's current context, 3.5 ties v3, which reproduces the repo's own finding. Once the
high-cardinality columns are included, 3.5 is better than v3 and benefits more from that context. Both pre-registered
hypotheses are supported.

**Caveats.** Only 3 datasets and 15 tables; the effect is modest (about +2 pts precision@k). Corruptions are synthetic. No
non-TabPFN baselines were run on these tables, CPU only, TabPFN 9.0.0 (TabLint pins 9.1.0, which was not available
on the internal index). auto_mpg shows almost no effect: car names rarely repeat in 398 rows.

---

## 4. Improvement handoff (prioritized)

### P0: credibility (about an hour)
1. **Replace the headline** in `README.md` and `docs/BENCHMARKS.md` with the full pre-registered 14-dataset result (13/14,
   +19.0 pts, p=0.00018). Delete the "selected subset" figure, or label it secondary.
2. **Replace the video** with a real ~90 s screen recording. The categorical engine exists, so capture an actual
   categorical flag instead of the illustrative USA → Japan suggestion.
3. **Make CI green:** add `timeout-minutes: 15` to the `notebook-widget` job in `.github/workflows/ci.yml` and rerun until the
   badge passes (or remove the badge).
4. **Lead with real finds:** Titanic (Barkworth recorded as 80, actually 47), diamonds depth 44 vs the implied 65.7, and Auto MPG.

### P1: make 3.5 matter (the winning story)
5. **Stop dropping high-cardinality columns.** In `proofread/core.py`, include string, object and category columns with more
   than 30 levels (up to e.g. 0.9·n distinct, and excluding near-unique IDs or free text) as **declared categorical** context,
   using sorted ordinal codes. Sketch (untested):
   ```python
   def context_columns(self, df, label=None, columns=None, max_unique_frac=0.9):
       """Categorical context for prediction: every non-numeric column that is not near-unique."""
       out = []
       for c in (columns or df.columns):
           if c == label or pd.api.types.is_numeric_dtype(df[c]):
               continue
           k = df[c].nunique(dropna=True)
           if 2 <= k <= max_unique_frac * df[c].notna().sum():
               out.append(c)
       return out

   def _codes(s):  # sorted ordinal codes; NaN stays NaN
       lv = {v: i for i, v in enumerate(sorted(s.dropna().astype(str).unique()))}
       return s.astype(str).where(s.notna()).map(lv).astype(float).to_numpy()
   ```
   Use `context_columns` (not `categorical_columns`) to build `C` in `check()`. Keep `categorical_columns` (≤30 levels) as
   the set of columns that are *checked*.
6. **Turn section 3 into a pre-registered benchmark in the repo.** Add more high-cardinality tables (e.g. OpenML
   `road-safety`, `kick`, wine reviews with variety/winery, Airbnb listings), include HGB with target encoding and a
   CatBoost baseline, and run 2000+ rows on GPU. Headline: "3.5 catches errors v3 misses when the row context includes IDs
   and codes."
7. **Optional free-text arm:** pass text columns as pandas `string` with `inference_config={"TRANSFORM_TEXT": True}`.
   This is version-agnostic, but it shows product value.
8. **Test the scoring claim directly:** apply the same PIT score to NGBoost, quantile-regression forests and conformalized
   HGB, and add cleanlab Datalab and PyOD ECOD baselines. If TabPFN still wins, the claim "foundation-model predictive
   distributions are what make cell-level checking work" is defensible.

### P2: correctness and speed
9. **Label as categorical in the numeric path:** in `check()`, append `y_codes` before computing `reg_cat`, or add its
   index to `reg_cat`.
10. **`_patterns`:** run it only over `cont` (≥ `min_distinct` levels), or require a sentinel-like value (0, −1, 99, 999,
    −999). Fix the message, which claims those cells are not flagged individually when the code only changes the `cause` text.
11. **Score cap:** clip at 1e-300 instead of 1e-12 (or rank ties by |value − median| / IQR) so extreme cells stay ordered.
12. **Speed:** reuse one estimator object per column, consider `fit_mode` caching, default to `fast=True` on CPU, and use
    3 folds when n > 5k. Report runtime per 1k rows.
13. **Iris misses:** document them in the README as an explicit limitation (small plausible slips go undetected).

### P3: polish
14. Move `showcase/` (the Remotion project and review SVGs) to a separate branch or repo, and settle on one name
    (TabLint vs proofread vs tabpfn-proofread).
15. Add a one-click Colab or Hugging Face Space that uses the Prior Labs API (Thinking mode), so judges can try it without a GPU.
16. File the three `tabpfn-extensions` CUDA bugs upstream and link the issues (this turns a negative into a contribution).

---

## 5. Bundle contents and how to reproduce

| File | Purpose |
|---|---|
| `PROTOCOL.md`, `PROTOCOL.sha256` | Protocol, hashed before the confirmation runs |
| `run.py` | Experiment (expects a TabLint checkout at `/tmp/TabLint` for `inject()` and `auto_mpg.csv`) |
| `analyze.py`, `analysis.txt` | Statistics and their output |
| `results/*.json` | 15 tables × {v3, v3.5} × {num, hc}: precision@k, AUROC, per-type AUROC, seconds |
| `log_*.txt` | Raw run logs |
| `pilot/` | Timing pilot (seed 999, not part of the analysis) |
| `smoke.py`, `peek.py` | Environment smoke test and dataset inspection |
| `requirements.txt` | Package versions used |

```sh
git clone https://github.com/James-Begin/TabLint /tmp/TabLint   # commit d0abdfc
uv venv -p 3.12 .venv && uv pip install -p .venv/bin/python -r requirements.txt
OMP_NUM_THREADS=4 .venv/bin/python run.py --out results_rerun   # ~45 min per dataset on CPU (M4 Pro)
.venv/bin/python analyze.py   # reads results/ (edit the glob to check results_rerun/)
```
TabPFN weights need first-use license acceptance and a Prior Labs auth token.
