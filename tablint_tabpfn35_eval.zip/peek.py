import openml, pandas as pd
openml.config.set_root_cache_directory('/tmp/tp35/openml')
for did in [42125, 42720]:
    try:
        d=openml.datasets.get_dataset(did, download_data=True)
        X,y,_,_=d.get_data(dataset_format="dataframe")
        print(did, d.name, X.shape, 'target', d.default_target_attribute)
        print(X.dtypes.to_string()); print(X.nunique().to_string()); print(X.head(3).T.to_string()[:1500])
    except Exception as e: print(did, 'ERR', e)
