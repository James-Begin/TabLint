"""Run PROTOCOL.md. Writes one JSON per (dataset, seed) to results/."""
import os, sys, json, time, importlib.util, argparse
from pathlib import Path
import numpy as np, pandas as pd, torch
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import KFold

# reuse TabLint's exact injection code
spec = importlib.util.spec_from_file_location("pc", "/tmp/TabLint/benchmarks/proofread_confirm.py")
src = Path("/tmp/TabLint/benchmarks/proofread_confirm.py").read_text()
ns = {}
exec(compile(src.split("def robust_scale")[0].replace("from benchmarks.common import factory, load_any", ""), "pc", "exec"), ns)
inject = ns["inject"]

import openml
openml.config.set_root_cache_directory("/tmp/tp35/openml")
from tabpfn import TabPFNRegressor
from tabpfn.constants import ModelVersion

SPECS = {
    "employee_salaries": dict(src=42125, n=1000,
        cont=["current_annual_salary", "2016_gross_pay_received", "2016_overtime_pay", "year_first_hired"],
        low=["gender", "assignment_category"], high=["employee_position_title", "division", "department"]),
    "medical_charges": dict(src=42720, n=1000,
        cont=["Total_Discharges", "Average_Covered_Charges", "Average_Total_Payments", "Average_Medicare_Payments"],
        low=[], high=["DRG_Definition", "Provider_State", "Hospital_Referral_Region_(HRR)_Description", "Provider_Id"]),
    "auto_mpg": dict(src="/tmp/TabLint/demo/video/auto_mpg.csv", n=None,
        cont=["mpg", "displacement", "horsepower", "weight", "acceleration"],
        low=["cylinders", "model_year", "origin"], high=["car"]),
}
VERS = {"v3": ModelVersion.V3, "v3.5": ModelVersion.V3_5}


def load(name):
    s = SPECS[name]
    if isinstance(s["src"], int):
        X, *_ = openml.datasets.get_dataset(s["src"], download_data=True).get_data(dataset_format="dataframe")
    else:
        X = pd.read_csv(s["src"])
    X = X[s["cont"] + s["low"] + s["high"]].dropna(subset=s["cont"]).reset_index(drop=True)
    return X


def codes(col):
    """ordinal codes from sorted unique values; NaN stays NaN"""
    lv = sorted(col.dropna().astype(str).unique())
    m = {v: i for i, v in enumerate(lv)}
    return col.astype(str).where(col.notna()).map(m).astype(float).to_numpy()


def run(name, seed, models):
    s = SPECS[name]; df0 = load(name); rng = np.random.default_rng(seed)
    df = df0 if s["n"] is None or len(df0) <= s["n"] else df0.iloc[rng.choice(len(df0), s["n"], replace=False)].reset_index(drop=True)
    X = df[s["cont"]].to_numpy(np.float64)
    Xe, mask, kind = inject(X, .03, rng)
    n, d = Xe.shape
    L = np.column_stack([codes(df[c]) for c in s["low"]]) if s["low"] else np.zeros((n, 0))
    H = np.column_stack([codes(df[c]) for c in s["high"]])
    rec = {"dataset": name, "seed": seed, "n": n, "errors": int(mask.sum()),
           "high_card_levels_in_sample": {c: int(df[c].nunique()) for c in s["high"]}, "runs": {}}
    for arm in ("num", "hc"):
        for vname in models:
            t0 = time.time(); S = np.zeros((n, d))
            for j in range(d):
                Z = np.c_[np.delete(Xe, j, 1), L] if arm == "num" else np.c_[np.delete(Xe, j, 1), L, H]
                cat = list(range(d - 1, Z.shape[1]))     # every low/high column is declared categorical
                t = Xe[:, j]; pit = np.full(n, .5)
                for tr, te in KFold(5, shuffle=True, random_state=seed).split(Z):
                    m = TabPFNRegressor.create_default_for_version(VERS[vname], device="cpu", random_state=seed,
                            ignore_pretraining_limits=True, categorical_features_indices=cat or None)
                    o = m.fit(Z[tr], t[tr]).predict(Z[te], output_type="full")
                    lg = o["logits"]; yy = torch.tensor(t[te], dtype=lg.dtype, device=lg.device)
                    F = o["criterion"].cdf(lg, yy.unsqueeze(-1)).squeeze(-1)
                    pit[te] = np.clip(np.nan_to_num(F.detach().double().cpu().numpy().reshape(-1), nan=.5), 1e-9, 1 - 1e-9)
                S[:, j] = -np.log(2 * np.minimum(pit, 1 - pit))
            f = S.ravel(); mm = mask.ravel(); k = int(mm.sum())
            r = {"precision_at_k": float(mm[np.argsort(-f, kind="stable")[:k]].mean()), "auroc": float(roc_auc_score(mm, f)),
                 "seconds": time.time() - t0, "by_type": {}}
            for tn in ("decimal", "swap", "offset", "zero", "transposition"):
                pos = kind.ravel() == tn
                if pos.sum():
                    r["by_type"][tn] = float(roc_auc_score(mm[pos | ~mm], f[pos | ~mm]))
            rec["runs"][f"{vname}|{arm}"] = r
            print(name, seed, vname, arm, "P@k %.3f AUROC %.3f %.0fs" % (r["precision_at_k"], r["auroc"], r["seconds"]), flush=True)
    return rec


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--datasets", default=",".join(SPECS))
    ap.add_argument("--seeds", default="1001,1002,1003,1004,1005"); ap.add_argument("--out", default="results")
    a = ap.parse_args(); out = Path(a.out); out.mkdir(exist_ok=True)
    for ds in a.datasets.split(","):
        for sd in map(int, a.seeds.split(",")):
            f = out / f"{ds}_{sd}.json"
            if f.exists():
                continue
            f.write_text(json.dumps(run(ds, sd, list(VERS)), indent=1))
