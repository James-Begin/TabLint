TabLint — saved VS Code demo

1. In VS Code, run Extensions: Install from VSIX… and select tablint.vsix.
2. Open this extracted folder, then open auto_mpg_dirty.csv.
3. Hover 4354.0 on line 183; inspect 0.0 horsepower on line 177 with Quick Fix (Ctrl+. / Cmd+.).
4. Run TabLint: Open decision ledger to view or undo decisions.

The saved report replays without Python, model weights, a GPU or an API key.
CSV/report data: Auto MPG by R. Quinlan, UCI, https://doi.org/10.24432/C5859H, CC BY 4.0.
The dirty CSV contains eight deliberate errors. Source, licensing, setup and provenance: https://github.com/James-Begin/TabLint
Extension code: Apache-2.0.
