import * as vscode from "vscode";
import * as fs from "fs";
import * as path from "path";
import { exec } from "child_process";
import { mapIssues, Mapped } from "./mapping";

const collection = vscode.languages.createDiagnosticCollection("proofread");
const fixes = new Map<string, Map<string, Mapped>>();   // uri -> "line:start" -> mapped issue
let status: vscode.StatusBarItem;

const isCsv = (doc: vscode.TextDocument) => doc.uri.scheme === "file" && doc.fileName.toLowerCase().endsWith(".csv");
const sidecar = (file: string) => file.replace(/\.csv$/i, "") + ".proofread.json";

function load(doc: vscode.TextDocument, announce = false): void {
  if (!isCsv(doc)) return;
  const p = sidecar(doc.fileName);
  if (!fs.existsSync(p)) { if (announce) vscode.window.showInformationMessage("Proofread: no saved report next to this CSV. Run “Proofread: Check this CSV”."); return; }
  let report: any;
  try { report = JSON.parse(fs.readFileSync(p, "utf8")); } catch { vscode.window.showWarningMessage(`Proofread: could not read ${path.basename(p)}`); return; }
  if (report.schema !== "proofread/1") return;
  const { mapped, skipped, multiline } = mapIssues(doc.getText(), report.issues ?? []);
  const diags: vscode.Diagnostic[] = []; const byKey = new Map<string, Mapped>();
  let stale = 0;
  for (const m of mapped) {
    if (!m.matchesReport) { stale++; continue; }          // cell edited since the report: don't squiggle it
    const range = new vscode.Range(m.line, m.start, m.line, m.end);
    const d = new vscode.Diagnostic(range, m.message, m.kind === "label" ? vscode.DiagnosticSeverity.Information : vscode.DiagnosticSeverity.Warning);
    d.source = "Proofread (TabPFN-3.5)"; d.code = m.kind;
    diags.push(d); byKey.set(`${m.line}:${m.start}`, m);
  }
  collection.set(doc.uri, diags); fixes.set(doc.uri.toString(), byKey);
  status.text = `$(eye) Proofread: ${diags.length} issue${diags.length === 1 ? "" : "s"}`; status.show();
  const notes = [skipped && `${skipped} issues could not be placed`, stale && `${stale} cells changed since the report`,
                 multiline && "quoted multi-line fields are not supported"].filter(Boolean);
  if (announce || notes.length) vscode.window.showInformationMessage(`Proofread: ${diags.length} issues${notes.length ? " (" + notes.join("; ") + ")" : ""}.`);
}

async function check(): Promise<void> {
  const ed = vscode.window.activeTextEditor;
  if (!ed || !isCsv(ed.document)) { vscode.window.showWarningMessage("Proofread: open a .csv file first."); return; }
  await ed.document.save();
  const cfg = vscode.workspace.getConfiguration("proofread");
  let label = cfg.get<string>("labelColumn", "");
  if (!label) {
    const header = ed.document.lineAt(0).text.split(",").map(s => s.replace(/^"|"$/g, ""));
    const pick = await vscode.window.showQuickPick(["(no label column)", ...header], { placeHolder: "Label column to check (optional)" });
    if (pick === undefined) return;
    label = pick === "(no label column)" ? "" : pick;
  }
  const file = ed.document.fileName; const report = sidecar(file);
  const q = (s: string) => `"${s.replace(/"/g, '\\"')}"`;
  const cmd = `${cfg.get<string>("command", "uv run proofread")} check ${q(file)} --report ${q(report)} --out ${q(file.replace(/\.csv$/i, "") + ".proofread")}` +
              ` --threshold ${cfg.get<number>("threshold", 2)}${label ? " --label " + q(label) : ""}`;
  const cwd = vscode.workspace.getWorkspaceFolder(ed.document.uri)?.uri.fsPath ?? path.dirname(file);
  await vscode.window.withProgress({ location: vscode.ProgressLocation.Notification, title: "Proofread: TabPFN-3.5 is reading the table…", cancellable: false },
    () => new Promise<void>((resolve) => {
      exec(cmd, { cwd, maxBuffer: 64 * 1024 * 1024 }, (err, _out, stderr) => {
        if (err) vscode.window.showErrorMessage(`Proofread failed: ${(stderr || err.message).split("\n").filter(Boolean).slice(-3).join(" ")}`);
        else load(ed.document, true);
        resolve();
      });
    }));
}

class Fixer implements vscode.CodeActionProvider {
  provideCodeActions(doc: vscode.TextDocument, _r: vscode.Range, ctx: vscode.CodeActionContext): vscode.CodeAction[] {
    const out: vscode.CodeAction[] = []; const byKey = fixes.get(doc.uri.toString());
    for (const d of ctx.diagnostics.filter(d => d.source === "Proofread (TabPFN-3.5)")) {
      const m = byKey?.get(`${d.range.start.line}:${d.range.start.character}`); if (!m) continue;
      const fix = new vscode.CodeAction(`Proofread: replace with ${m.suggestion}`, vscode.CodeActionKind.QuickFix);
      fix.edit = new vscode.WorkspaceEdit(); fix.edit.replace(doc.uri, d.range, m.suggestion); fix.diagnostics = [d]; fix.isPreferred = true;
      const dismiss = new vscode.CodeAction("Proofread: dismiss this flag", vscode.CodeActionKind.QuickFix);
      dismiss.command = { command: "proofread.dismiss", title: "dismiss", arguments: [doc.uri, d] }; dismiss.diagnostics = [d];
      out.push(fix, dismiss);
    }
    return out;
  }
}

export function activate(context: vscode.ExtensionContext): void {
  status = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
  status.command = "proofread.check";
  context.subscriptions.push(collection, status,
    vscode.commands.registerCommand("proofread.check", check),
    vscode.commands.registerCommand("proofread.reload", () => vscode.window.activeTextEditor && load(vscode.window.activeTextEditor.document, true)),
    vscode.commands.registerCommand("proofread.clear", () => { collection.clear(); status.hide(); }),
    vscode.commands.registerCommand("proofread.dismiss", (uri: vscode.Uri, d: vscode.Diagnostic) =>
      collection.set(uri, (collection.get(uri) ?? []).filter(x => x !== d))),
    vscode.languages.registerCodeActionsProvider({ scheme: "file", pattern: "**/*.csv" }, new Fixer(), { providedCodeActionKinds: [vscode.CodeActionKind.QuickFix] }),
    vscode.workspace.onDidOpenTextDocument(doc => load(doc)),
    vscode.workspace.onDidSaveTextDocument(doc => load(doc)),
    vscode.window.onDidChangeActiveTextEditor(ed => { if (ed && isCsv(ed.document)) load(ed.document); else status.hide(); }));
  vscode.workspace.textDocuments.forEach(doc => load(doc));
}

export function deactivate(): void { collection.dispose(); }
