# Proofread for VS Code: spellcheck for tables

Open a CSV and Proofread underlines cells that are implausible *for their row*, according to TabPFN-3.5, just like
a spellchecker.

- **Hover** a squiggle to see what TabPFN-3.5 expects, its 80% range, the likely slip (×10, ÷10, swapped digits,
  0-for-missing…) and related columns in that row.
- **Quick fix** (💡 or `Ctrl/Cmd + .`): "Replace with 21.15" or "Dismiss this flag".
- The **Problems panel** lists every flagged cell and label.

## How it works
- The extension reads a saved report next to the CSV (`data.csv` → `data.proofread.json`), so viewing needs no model
  and no GPU.
- **Proofread: Check this CSV with TabPFN-3.5** runs the Proofread CLI (`uv run proofread check …` by default; see
  `proofread.command`) in your workspace and loads the result.
- Cells you've edited since the report are not squiggled.

## Settings
- `proofread.command`: how to run the CLI (default `uv run proofread`).
- `proofread.threshold`: flag cells with surprise ≥ this value. 2 gives about 88% precision and 53% recall; 3 gives
  about 95% and 19% (benchmark).
- `proofread.labelColumn`: optional label column to check.

## Limitations
- Plain comma-separated files with one record per line. Quoted fields may contain commas, but not line breaks.
- A flag is a prompt to check the source, not proof of an error.
