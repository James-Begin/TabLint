// Runs inside a real VS Code instance (via @vscode/test-electron). No mocha; throws on failure.
import * as vscode from "vscode";
import * as path from "path";
import * as assert from "assert";

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

export async function run(): Promise<void> {
  const csv = path.resolve(__dirname, "..", "..", "..", "test", "fixtures", "breast_dirty.csv");
  const doc = await vscode.workspace.openTextDocument(csv);
  await vscode.window.showTextDocument(doc);
  let diags: readonly vscode.Diagnostic[] = [];
  for (let i = 0; i < 50 && diags.length === 0; i++) { await sleep(200); diags = vscode.languages.getDiagnostics(doc.uri); }
  const ours = diags.filter(d => d.source === "Proofread (TabPFN-3.5)");
  assert.strictEqual(ours.length, 80, `expected 80 squiggles, got ${ours.length}`);
  const top = ours.find(d => doc.getText(d.range) === "211.0") ?? ours[0];
  console.log(`[integration] ${ours.length} diagnostics; e.g. line ${top.range.start.line + 1}: "${doc.getText(top.range)}" — ${top.message.slice(0, 110)}`);
  const actions = await vscode.commands.executeCommand<vscode.CodeAction[]>("vscode.executeCodeActionProvider", doc.uri, top.range);
  const fix = actions.find(a => a.title.startsWith("Proofread: replace with"));
  assert.ok(fix && fix.edit, "quick fix offered");
  console.log(`[integration] quick fix: ${fix!.title}`);
  await vscode.workspace.applyEdit(fix!.edit!);
  const replaced = doc.getText(new vscode.Range(top.range.start, top.range.start.translate(0, fix!.title.replace("Proofread: replace with ", "").length)));
  console.log(`[integration] after fix the cell reads "${replaced}"`);
  assert.ok(fix!.title.endsWith(replaced));
  await vscode.commands.executeCommand("workbench.action.files.revert");
  console.log("[integration] PASS");
}
