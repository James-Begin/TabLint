import * as fs from "fs";
import * as path from "path";
import { downloadAndUnzipVSCode, runTests } from "@vscode/test-electron";

(async () => {
  try {
    let exe = await downloadAndUnzipVSCode();
    // Recent macOS builds name the binary "Code"; @vscode/test-electron 2.5.x still points at "Electron".
    const alt = path.join(path.dirname(exe), "Code");
    if (!fs.existsSync(exe) && fs.existsSync(alt)) exe = alt;
    await runTests({
      vscodeExecutablePath: exe,
      extensionDevelopmentPath: path.resolve(__dirname, "..", "..", ".."),
      extensionTestsPath: path.resolve(__dirname, "suite"),
      launchArgs: ["--disable-extensions", "--skip-welcome", "--skip-release-notes"],
    });
  } catch (e) { console.error("integration test failed", e); process.exit(1); }
})();
